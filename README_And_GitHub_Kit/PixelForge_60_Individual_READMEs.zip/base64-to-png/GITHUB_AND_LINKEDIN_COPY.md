# BASE64 to PNG: GitHub and LinkedIn publishing kit

## Repository name

`base64-to-png`

## GitHub description

Free BASE64 to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend.

## GitHub topics

`image-converter`, `image-tools`, `javascript`, `github-pages`, `browser-based`, `privacy-first`, `base64-to-png`, `base64`

## SEO meta description

Free BASE64 to PNG converter. Upload or drag multiple images, resize with preserved proportions, preview, convert privately in your browser and download files or a ZIP.

## Ready-to-edit LinkedIn post

🚀 Introducing **BASE64 to PNG Converter — PixelForge**

Extract a PNG file from an embedded image data URL.

✅ Fully browser-based conversion — no image upload required by the app
✅ Drag & drop, multi-file queue and instant image previews
✅ Resize presets, individual downloads and batch ZIP export
✅ Mobile-friendly interface and no server or API key

Typical workflow: paste an image data URL from a test response and download the decoded image.

Built with HTML, CSS and vanilla JavaScript. Open source under MIT.

Live demo: https://YOUR-USERNAME.github.io/base64-to-png/
GitHub: https://github.com/YOUR-USERNAME/base64-to-png

#ImageConverter #BASE64 #PNG #WebDevelopment #OpenSource #GitHubPages

## How to publish

1. Upload this project to GitHub.
2. Enable Pages in Settings → Pages.
3. Replace placeholder links with the exact GitHub and live Pages URLs.
4. Publish the LinkedIn text using real screenshots and real, tested claims.
