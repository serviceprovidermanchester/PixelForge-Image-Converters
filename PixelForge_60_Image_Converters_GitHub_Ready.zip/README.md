# PixelForge — 60 Independent Image Conversion Tools

## Contents

60 independent, standalone GitHub Pages applications; each has its own index.html, style.css, app.js, favicon.svg, README, and MIT license. No npm, Python server, API keys, or CDN needed to run any tool.

**Single hosted directory site:** Upload this whole extracted folder to one GitHub repository and enable Pages from the root. Its homepage lists all 60 tools.

**Separate repositories (recommended for independent URLs):** Download any of the 60 separate ZIPs under `Individual_Tool_ZIPs`; unzip one ZIP into one new GitHub repository. Enable Pages in Settings → Pages, primary branch, /(root).

## What to expect

- PNG, JPG, WebP, GIF, BMP, ICO, SVG, AVIF input, plus Base64 text input for two tools.
- PNG, JPG, WebP, BMP, ICO, SVG, PDF, Base64 output.
- GIF input is **first-frame only** (not a GIF animation encoder).
- SVG output **embeds raster artwork** (not a vectorizer).
- ICO output: 256×256 PNG-in-ICO. BMP output: 24-bit, white background.
- AVIF and ICO input browser decoding support varies; unsupported inputs raise a clear error.
- PDF output: single page per input, image fitted to A4.
- Batch ZIP packaging is uncompressed ZIP and may use a lot of RAM for very large batches.
- Files are processed locally; no images are transmitted.

## Publication & SEO

Each site has unique title/meta description and mobile-friendly UI. Customize site name, favicon, copy, and legal pages before commercial launch; do not claim a vectorizing/animated feature that isn't supported.

MIT license applies individually to all 60 tool folders. See individual README.md and LICENSE.
