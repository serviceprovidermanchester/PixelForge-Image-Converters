# WEBP to PNG: GitHub and LinkedIn publishing kit

## Repository name

`webp-to-png`

## GitHub description

Free WEBP to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend.

## GitHub topics

`image-converter`, `image-tools`, `javascript`, `github-pages`, `browser-based`, `privacy-first`, `webp-to-png`

## SEO meta description

Free WEBP to PNG converter. Upload or drag multiple images, resize with preserved proportions, preview, convert privately in your browser and download files or a ZIP.

## Ready-to-edit LinkedIn post

🚀 Introducing **WEBP to PNG Converter — PixelForge**

Turn WebP graphics into editable PNG files for image tools that expect PNG.

✅ Fully browser-based conversion — no image upload required by the app
✅ Drag & drop, multi-file queue and instant image previews
✅ Resize presets, individual downloads and batch ZIP export
✅ Mobile-friendly interface and no server or API key

Typical workflow: import an image exported by a modern website and save it as PNG.

Built with HTML, CSS and vanilla JavaScript. Open source under MIT.

Live demo: https://YOUR-USERNAME.github.io/webp-to-png/
GitHub: https://github.com/YOUR-USERNAME/webp-to-png

#ImageConverter #WEBP #PNG #WebDevelopment #OpenSource #GitHubPages

## How to publish

1. Upload this project to GitHub.
2. Enable Pages in Settings → Pages.
3. Replace placeholder links with the exact GitHub and live Pages URLs.
4. Publish the LinkedIn text using real screenshots and real, tested claims.
