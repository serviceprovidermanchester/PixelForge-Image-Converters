# PixelForge — 60 Independent Image Converters

A library of **60 standalone, GitHub Pages-ready image conversion tools**, each with its own polished responsive UI, pure JavaScript converter, complete developer/user `README.md`, MIT license, and GitHub/LinkedIn publishing copy.

## What's included

- **60 independent website projects** in directories named by format pair.
- **60 individual ZIP files** in the accompanying `Individual_Tool_ZIPs` folder.
- **60 enriched `README.md` files** with unique format behavior, features, instructions, limitations, usage examples, FAQs, GitHub SEO descriptions/topics and LinkedIn post drafts.
- **60 `GITHUB_AND_LINKEDIN_COPY.md` files** for quick repository and promotional setup.
- A master catalog (`manifest.csv`, `GITHUB_REPOSITORY_METADATA.csv`) and [`GITHUB_PUBLISHING_GUIDE.md`](GITHUB_PUBLISHING_GUIDE.md).

## 60 tools

| # | Tool | ZIP | Repository description |
|---:|---|---|---|
| 01 | [PNG → JPG](png-to-jpg/README.md) | `png-to-jpg.zip` | Free PNG to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 02 | [PNG → WEBP](png-to-webp/README.md) | `png-to-webp.zip` | Free PNG to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 03 | [PNG → BMP](png-to-bmp/README.md) | `png-to-bmp.zip` | Free PNG to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 04 | [PNG → ICO](png-to-ico/README.md) | `png-to-ico.zip` | Free PNG to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 05 | [PNG → SVG](png-to-svg/README.md) | `png-to-svg.zip` | Free PNG to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 06 | [PNG → PDF](png-to-pdf/README.md) | `png-to-pdf.zip` | Free PNG to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 07 | [PNG → BASE64](png-to-base64/README.md) | `png-to-base64.zip` | Free PNG to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 08 | [JPG → PNG](jpg-to-png/README.md) | `jpg-to-png.zip` | Free JPG to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 09 | [JPG → WEBP](jpg-to-webp/README.md) | `jpg-to-webp.zip` | Free JPG to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 10 | [JPG → BMP](jpg-to-bmp/README.md) | `jpg-to-bmp.zip` | Free JPG to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 11 | [JPG → ICO](jpg-to-ico/README.md) | `jpg-to-ico.zip` | Free JPG to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 12 | [JPG → SVG](jpg-to-svg/README.md) | `jpg-to-svg.zip` | Free JPG to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 13 | [JPG → PDF](jpg-to-pdf/README.md) | `jpg-to-pdf.zip` | Free JPG to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 14 | [JPG → BASE64](jpg-to-base64/README.md) | `jpg-to-base64.zip` | Free JPG to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 15 | [WEBP → PNG](webp-to-png/README.md) | `webp-to-png.zip` | Free WEBP to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 16 | [WEBP → JPG](webp-to-jpg/README.md) | `webp-to-jpg.zip` | Free WEBP to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 17 | [WEBP → BMP](webp-to-bmp/README.md) | `webp-to-bmp.zip` | Free WEBP to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 18 | [WEBP → ICO](webp-to-ico/README.md) | `webp-to-ico.zip` | Free WEBP to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 19 | [WEBP → SVG](webp-to-svg/README.md) | `webp-to-svg.zip` | Free WEBP to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 20 | [WEBP → PDF](webp-to-pdf/README.md) | `webp-to-pdf.zip` | Free WEBP to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 21 | [WEBP → BASE64](webp-to-base64/README.md) | `webp-to-base64.zip` | Free WEBP to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 22 | [GIF → PNG](gif-to-png/README.md) | `gif-to-png.zip` | Free GIF to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 23 | [GIF → JPG](gif-to-jpg/README.md) | `gif-to-jpg.zip` | Free GIF to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 24 | [GIF → WEBP](gif-to-webp/README.md) | `gif-to-webp.zip` | Free GIF to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 25 | [GIF → BMP](gif-to-bmp/README.md) | `gif-to-bmp.zip` | Free GIF to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 26 | [GIF → ICO](gif-to-ico/README.md) | `gif-to-ico.zip` | Free GIF to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 27 | [GIF → SVG](gif-to-svg/README.md) | `gif-to-svg.zip` | Free GIF to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 28 | [GIF → PDF](gif-to-pdf/README.md) | `gif-to-pdf.zip` | Free GIF to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 29 | [GIF → BASE64](gif-to-base64/README.md) | `gif-to-base64.zip` | Free GIF to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 30 | [BMP → PNG](bmp-to-png/README.md) | `bmp-to-png.zip` | Free BMP to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 31 | [BMP → JPG](bmp-to-jpg/README.md) | `bmp-to-jpg.zip` | Free BMP to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 32 | [BMP → WEBP](bmp-to-webp/README.md) | `bmp-to-webp.zip` | Free BMP to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 33 | [BMP → ICO](bmp-to-ico/README.md) | `bmp-to-ico.zip` | Free BMP to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 34 | [BMP → SVG](bmp-to-svg/README.md) | `bmp-to-svg.zip` | Free BMP to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 35 | [BMP → PDF](bmp-to-pdf/README.md) | `bmp-to-pdf.zip` | Free BMP to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 36 | [BMP → BASE64](bmp-to-base64/README.md) | `bmp-to-base64.zip` | Free BMP to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 37 | [ICO → PNG](ico-to-png/README.md) | `ico-to-png.zip` | Free ICO to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 38 | [ICO → JPG](ico-to-jpg/README.md) | `ico-to-jpg.zip` | Free ICO to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 39 | [ICO → WEBP](ico-to-webp/README.md) | `ico-to-webp.zip` | Free ICO to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 40 | [ICO → BMP](ico-to-bmp/README.md) | `ico-to-bmp.zip` | Free ICO to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 41 | [ICO → SVG](ico-to-svg/README.md) | `ico-to-svg.zip` | Free ICO to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 42 | [ICO → PDF](ico-to-pdf/README.md) | `ico-to-pdf.zip` | Free ICO to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 43 | [ICO → BASE64](ico-to-base64/README.md) | `ico-to-base64.zip` | Free ICO to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 44 | [SVG → PNG](svg-to-png/README.md) | `svg-to-png.zip` | Free SVG to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 45 | [SVG → JPG](svg-to-jpg/README.md) | `svg-to-jpg.zip` | Free SVG to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 46 | [SVG → WEBP](svg-to-webp/README.md) | `svg-to-webp.zip` | Free SVG to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 47 | [SVG → BMP](svg-to-bmp/README.md) | `svg-to-bmp.zip` | Free SVG to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 48 | [SVG → ICO](svg-to-ico/README.md) | `svg-to-ico.zip` | Free SVG to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 49 | [SVG → PDF](svg-to-pdf/README.md) | `svg-to-pdf.zip` | Free SVG to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 50 | [SVG → BASE64](svg-to-base64/README.md) | `svg-to-base64.zip` | Free SVG to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 51 | [AVIF → PNG](avif-to-png/README.md) | `avif-to-png.zip` | Free AVIF to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 52 | [AVIF → JPG](avif-to-jpg/README.md) | `avif-to-jpg.zip` | Free AVIF to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 53 | [AVIF → WEBP](avif-to-webp/README.md) | `avif-to-webp.zip` | Free AVIF to WEBP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 54 | [AVIF → BMP](avif-to-bmp/README.md) | `avif-to-bmp.zip` | Free AVIF to BMP image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 55 | [AVIF → ICO](avif-to-ico/README.md) | `avif-to-ico.zip` | Free AVIF to ICO image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 56 | [AVIF → SVG](avif-to-svg/README.md) | `avif-to-svg.zip` | Free AVIF to SVG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 57 | [AVIF → PDF](avif-to-pdf/README.md) | `avif-to-pdf.zip` | Free AVIF to PDF image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 58 | [AVIF → BASE64](avif-to-base64/README.md) | `avif-to-base64.zip` | Free AVIF to BASE64 image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 59 | [BASE64 → PNG](base64-to-png/README.md) | `base64-to-png.zip` | Free BASE64 to PNG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |
| 60 | [BASE64 → JPG](base64-to-jpg/README.md) | `base64-to-jpg.zip` | Free BASE64 to JPG image converter — private in-browser processing, batch uploads, resize and downloadable results. No backend. |

## Deployment

For a single tool, download its ZIP, unzip it, create a repo named after its slug, push the unzipped files to repository root, and enable GitHub Pages from the default branch root.

**Do not upload only a ZIP file to the repository and expect GitHub Pages to execute it.** The repo must have `index.html` in the publication root.

See [`GITHUB_PUBLISHING_GUIDE.md`](GITHUB_PUBLISHING_GUIDE.md) for details.

## Conversion expectations

Processing stays in the browser; no backend, image upload, SDK, or API key. Controls include multi-file upload, drag/drop, thumbnails, resize presets, custom width, single downloads and bulk ZIP. The quality slider is available for JPG, WebP and PDF outputs. GIF input is first-frame only. SVG output embeds raster PNG data, rather than tracing vectors. PDF output is one A4 page per input. Base64 output is a text data URL from a rendered PNG. ICO output is a single 256px PNG-backed entry.

## Licensing

MIT. Each project contains its own `LICENSE`.
